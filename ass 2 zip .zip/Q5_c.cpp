//efficient way to store lower triangular matrix in 1d array

#include <iostream>
using namespace std;

// Function to map 2D indices to 1D index for lower triangular matrix
int mapIndex(int i, int j) {
    return (i * (i + 1)) / 2 + j;
}

// Function to store lower triangular matrix in a 1D array
void storeLowerTriangular(int n, int matrix[][100], int lowerArray[]) {
    int index = 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j <= i; j++) {
            lowerArray[index++] = matrix[i][j];
        }
    }
}

// Function to print the 1D array
void printLowerTriangular(int lowerArray[], int size) {
    for (int i = 0; i < size; i++) {
        cout << lowerArray[i] << " ";
    }
    cout << endl;
}

int main() {
    int n = 4; // Size of the matrix
    int matrix[100][100] = {
        {1, 0, 0, 0},
        {2, 3, 0, 0},
        {4, 5, 6, 0},
        {7, 8, 9, 10}
    };

    int lowerArray[n * (n + 1) / 2]; // 1D array to store the lower triangular elements

    storeLowerTriangular(n, matrix, lowerArray);

    cout << "Lower triangular matrix stored in 1D array: ";
    printLowerTriangular(lowerArray, n * (n + 1) / 2);

    return 0;
}