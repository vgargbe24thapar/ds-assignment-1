//Write a program to count the total number of distinct elements in an array of length n.

#include <iostream>
using namespace std;

void sortArray(int arr[], int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                // Swap arr[j] and arr[j+1]
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int countDistinct(int arr[], int size) {
    if (size == 0) return 0;

    sortArray(arr, size);

    int distinctCount = 1; // First element is always distinct

    for (int i = 1; i < size; i++) {
        if (arr[i] != arr[i - 1]) {
            distinctCount++;
        }
    }

    return distinctCount;
}

int main() {
    int arr[] = {1, 2, 2, 3, 4, 4, 5};
    int size = sizeof(arr) / sizeof(arr[0]);

    int distinctElements = countDistinct(arr, size);
    cout << "Total number of distinct elements: " << distinctElements << endl;

    return 0;
}


