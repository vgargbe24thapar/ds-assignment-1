//Write a program to convert a character from uppercase to lowercase.

#include <iostream>
using namespace std;

char toLowerCase(char ch) {
    if (ch >= 'A' && ch <= 'Z') {
        return ch + ('a' - 'A'); // Convert to lowercase
    }
    return ch; // Return the character as is if it's not uppercase
}

int main() {
    char ch;
    cout << "Enter an uppercase character: ";
    cin >> ch;

    char lowerCh = toLowerCase(ch);
    cout << "Lowercase character: " << lowerCh << endl;

    return 0;
}
