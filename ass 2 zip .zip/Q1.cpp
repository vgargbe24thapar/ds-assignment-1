//Implement the Binary search algorithm regarded as a fast search algorithm with
//run-time complexity of Ο(log n) in comparison to the Linear Search.

#include <iostream>
using namespace std;

void binarysearch(int arr[], int size, int key)
{
    int start = 0;
    int end = size - 1;
    int mid = (start + end) / 2;

    while (start <= end)
    {
        if (arr[mid] == key)
        {
            cout << "Element found at index " << mid << endl;
            return;
        }
        else if (arr[mid] < key)
        {
            start = mid + 1;
        }
        else
        {
            end = mid - 1;
        }
        mid = (start + end) / 2;
    }
    cout << "Element not found in the array" << endl;
}

void linearsearch(int arr[], int size, int key)
{
    for (int i = 0; i < size; i++)
    {
        if (arr[i] == key)
        {
            cout << "Element found at index " << i << endl;
            return;
        }
    }
    cout << "Element not found in the array" << endl;
}

int main ()
{

    int arr[] = {2, 3, 4, 10, 40};

    


    return 0;
}