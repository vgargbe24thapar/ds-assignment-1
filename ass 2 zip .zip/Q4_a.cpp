//Write a program to concatenate one string to another string.

#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    char s1[100], s2[100];

    cout<<"Enter the first string: "<<endl;
    cin>>s1;

    cout<<"Enter the second string: "<<endl;
    cin>>s2;

    int i=0;
    while(s1[i] != '\0')
    {
        i++;
    }

    int j = 0;
    while(s2[j] != '\0')
    {
        s1[i] = s2[j];
        i++;
        j++;

    }

    s1[i] = '\0';

    cout<<s1;

}