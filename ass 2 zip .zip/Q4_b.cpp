//WAP to reverse the string

#include <iostream>
using namespace std;

void reverseString(char arr[], int size)
{   
    int i = 0;
    int j = size - 1;

    while(i < j)
    {
        char temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
        i++;
        j--;
    }
}


int main()
{

    char s1[100];

    cout<<"Enter the string to be reversed: ";
    cin>>s1;

    int size = 0;
    while(s1[size] != '\0'){
        size++;
    }

    reverseString(s1, size);
    return 0;
}