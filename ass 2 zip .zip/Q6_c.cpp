//multiplication of two matrices in sparse matrix

#include <iostream>
using namespace std;

// Function to display a sparse matrix in triplet form
void displaySparseMatrix(int sparse[][3], int size) {
    cout << "Row\tCol\tValue" << endl;
    for (int i = 0; i < size; i++) {
        cout << sparse[i][0] << "\t" << sparse[i][1] << "\t" << sparse[i][2] << endl;
    }
}

// Function to multiply two sparse matrices
void multiplySparseMatrices(int sparse1[][3], int size1, int sparse2[][3], int size2, int result[][3]) {
    if (sparse1[0][1] != sparse2[0][0]) {
        cout << "Matrix multiplication not possible: incompatible dimensions." << endl;
        return;
    }

    int k = 1; // Index for the result matrix
    result[0][0] = sparse1[0][0]; // Rows of the result = rows of sparse1
    result[0][1] = sparse2[0][1]; // Columns of the result = columns of sparse2
    result[0][2] = 0;             // Initialize the number of non-zero elements

    // Multiply sparse1 and sparse2
    for (int i = 1; i <= sparse1[0][2]; i++) {
        for (int j = 1; j <= sparse2[0][2]; j++) {
            if (sparse1[i][1] == sparse2[j][0]) { // Column of sparse1 matches row of sparse2
                int row = sparse1[i][0];
                int col = sparse2[j][1];
                int value = sparse1[i][2] * sparse2[j][2];

                // Check if the (row, col) already exists in the result
                bool found = false;
                for (int x = 1; x < k; x++) {
                    if (result[x][0] == row && result[x][1] == col) {
                        result[x][2] += value; // Add to the existing value
                        found = true;
                        break;
                    }
                }

                // If not found, add a new entry
                if (!found) {
                    result[k][0] = row;
                    result[k][1] = col;
                    result[k][2] = value;
                    k++;
                }
            }
        }
    }

    // Update the number of non-zero elements in the result
    result[0][2] = k - 1;
}

int main() {
    // Sparse matrix 1 in triplet form: [row, col, value]
    int sparse1[5][3] = {
        {3, 3, 4}, // 3x3 matrix with 4 non-zero elements
        {0, 0, 1},
        {0, 2, 2},
        {1, 1, 3},
        {2, 0, 4}
    };

    // Sparse matrix 2 in triplet form: [row, col, value]
    int sparse2[5][3] = {
        {3, 3, 4}, // 3x3 matrix with 4 non-zero elements
        {0, 1, 5},
        {1, 2, 6},
        {2, 0, 7},
        {2, 2, 8}
    };

    // Resultant sparse matrix
    int result[10][3]; // Maximum size = size1 * size2 (worst case)

    // Multiply the two sparse matrices
    multiplySparseMatrices(sparse1, 5, sparse2, 5, result);

    // Display the result
    cout << "Resultant Sparse Matrix:" << endl;
    displaySparseMatrix(result, result[0][2] + 1);

    return 0;
}
