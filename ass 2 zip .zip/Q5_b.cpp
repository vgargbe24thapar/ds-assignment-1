//efficient way to store tri-diagonal matrix in 1d array

#include <iostream>
using namespace std;

// Function to store a tri-diagonal matrix in a 1D array
void storeTriDiagonal(int n, int matrix[][100], int triArray[]) {
    int index = 0;

    // Store lower diagonal
    for (int i = 1; i < n; i++) {
        triArray[index++] = matrix[i][i - 1];
    }

    // Store main diagonal
    for (int i = 0; i < n; i++) {
        triArray[index++] = matrix[i][i];
    }

    // Store upper diagonal
    for (int i = 0; i < n - 1; i++) {
        triArray[index++] = matrix[i][i + 1];
    }
}

// Function to print the 1D array
void printTriDiagonal(int triArray[], int size) {
    for (int i = 0; i < size; i++) {
        cout << triArray[i] << " ";
    }
    cout << endl;
}

int main() {
    int n = 4; // Size of the matrix
    int matrix[100][100] = {
        {1, 2, 0, 0},
        {3, 4, 5, 0},
        {0, 6, 7, 8},
        {0, 0, 9, 10}
    };

    int triArray[3 * n - 2]; // 1D array to store the tri-diagonal elements

    storeTriDiagonal(n, matrix, triArray);

    cout << "Tri-diagonal matrix stored in 1D array: ";
    printTriDiagonal(triArray, 3 * n - 2);

    return 0;
}