//efficient way to store diagonal matrix in 1d array

#include <iostream>
using namespace std;

class DiagonalMatrix {
private:
    int* arr;
    int n; // Dimension of the matrix
public:
    DiagonalMatrix(int size) {
        n = size;
        arr = new int[n]; // Only n elements needed for diagonal matrix
    }

    ~DiagonalMatrix() {
        delete[] arr;
    }

    void set(int i, int j, int value) {
        if (i == j) {
            arr[i] = value; // Store only diagonal elements
        } else if (value != 0) {
            cout << "Only diagonal elements can be non-zero in a diagonal matrix." << endl;
        }
    }

    int get(int i, int j) {
        if (i == j) {
            return arr[i]; // Return the diagonal element
        } else {
            return 0; // Non-diagonal elements are zero
        }
    }

    void display() {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j) {
                    cout << arr[i] << " ";
                } else {
                    cout << "0 ";
                }
            }
            cout << endl;
        }
    }
};

int main() {
    int size;
    cout << "Enter the size of the diagonal matrix: ";
    cin >> size;

    DiagonalMatrix dm(size);

    cout << "Enter the diagonal elements:" << endl;
    for (int i = 0; i < size; i++) {
        int value;
        cout << "Element at (" << i << "," << i << "): ";
        cin >> value;
        dm.set(i, i, value);
    }

    cout << "The diagonal matrix is:" << endl;
    dm.display();

    return 0;
}