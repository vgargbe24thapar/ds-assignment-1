//efficient way to store symmetric matrix in 1d array

#include <iostream>
using namespace std;

// Function to map 2D indices to 1D index for symmetric matrix (using lower triangle)
int mapIndex(int i, int j) {
    if (i >= j) {
        return (i * (i + 1)) / 2 + j; // Mapping formula for lower triangle
    } else {
        return (j * (j + 1)) / 2 + i; // Optional: handle upper triangle (symmetric property)
    }
}

// Function to store symmetric matrix in a 1D array
void storeSymmetricMatrix(int n, int matrix[][100], int symArray[]) {
    int index = 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j <= i; j++) { // Only iterate through the lower triangle
            symArray[index++] = matrix[i][j];
        }
    }
}

// Function to print the 1D array
void printSymmetricMatrix(int symArray[], int size) {
    for (int i = 0; i < size; i++) {
        cout << symArray[i] << " ";
    }
    cout << endl;
}

int main() {
    int n = 4; // Size of the matrix
    int matrix[100][100] = {
        {1, 2, 3, 4},
        {2, 5, 6, 7},
        {3, 6, 8, 9},
        {4, 7, 9, 10}
    };

    int symArray[n * (n + 1) / 2]; // 1D array to store the symmetric matrix elements

    storeSymmetricMatrix(n, matrix, symArray);

    cout << "Symmetric matrix stored in 1D array: ";
    printSymmetricMatrix(symArray, n * (n + 1) / 2);

    return 0;
}