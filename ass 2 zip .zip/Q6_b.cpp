//addition of two matrices in sparse matrix

#include <iostream>
using namespace std;

// Function to display a sparse matrix in triplet form
void displaySparseMatrix(int sparse[][3], int size) {
    cout << "Row\tCol\tValue" << endl;
    for (int i = 0; i < size; i++) {
        cout << sparse[i][0] << "\t" << sparse[i][1] << "\t" << sparse[i][2] << endl;
    }
}

// Function to add two sparse matrices
void addSparseMatrices(int sparse1[][3], int size1, int sparse2[][3], int size2, int result[][3]) {
    int i = 1, j = 1, k = 1;

    // Copy the dimensions and initialize the result matrix
    result[0][0] = sparse1[0][0]; // Number of rows
    result[0][1] = sparse1[0][1]; // Number of columns
    result[0][2] = 0;             // Initialize the number of non-zero elements

    // Traverse both matrices
    while (i <= sparse1[0][2] && j <= sparse2[0][2]) {
        if (sparse1[i][0] < sparse2[j][0] || 
           (sparse1[i][0] == sparse2[j][0] && sparse1[i][1] < sparse2[j][1])) {
            // Copy element from sparse1
            result[k][0] = sparse1[i][0];
            result[k][1] = sparse1[i][1];
            result[k][2] = sparse1[i][2];
            i++;
        } else if (sparse1[i][0] > sparse2[j][0] || 
                  (sparse1[i][0] == sparse2[j][0] && sparse1[i][1] > sparse2[j][1])) {
            // Copy element from sparse2
            result[k][0] = sparse2[j][0];
            result[k][1] = sparse2[j][1];
            result[k][2] = sparse2[j][2];
            j++;
        } else {
            // Add values if row and column indices match
            result[k][0] = sparse1[i][0];
            result[k][1] = sparse1[i][1];
            result[k][2] = sparse1[i][2] + sparse2[j][2];
            i++;
            j++;
        }
        k++;
    }

    // Copy remaining elements from sparse1
    while (i <= sparse1[0][2]) {
        result[k][0] = sparse1[i][0];
        result[k][1] = sparse1[i][1];
        result[k][2] = sparse1[i][2];
        i++;
        k++;
    }

    // Copy remaining elements from sparse2
    while (j <= sparse2[0][2]) {
        result[k][0] = sparse2[j][0];
        result[k][1] = sparse2[j][1];
        result[k][2] = sparse2[j][2];
        j++;
        k++;
    }

    // Update the number of non-zero elements in the result
    result[0][2] = k - 1;
}

int main() {
    // Sparse matrix 1 in triplet form: [row, col, value]
    int sparse1[5][3] = {
        {4, 4, 4}, // 4x4 matrix with 4 non-zero elements
        {0, 1, 5},
        {1, 2, 8},
        {2, 0, 3},
        {3, 3, 6}
    };

    // Sparse matrix 2 in triplet form: [row, col, value]
    int sparse2[4][3] = {
        {4, 4, 3}, // 4x4 matrix with 3 non-zero elements
        {0, 1, 7},
        {1, 2, -8},
        {3, 3, 4}
    };

    // Resultant sparse matrix
    int result[10][3]; // Maximum size = size1 + size2

    // Add the two sparse matrices
    addSparseMatrices(sparse1, 5, sparse2, 4, result);

    // Display the result
    cout << "Resultant Sparse Matrix:" << endl;
    displaySparseMatrix(result, result[0][2] + 1);

    return 0;
}