//WAP to delete the vowels from a string

#include <iostream>
using namespace std;

void deleteVowels(char arr[], int size)
{
    int j = 0;
    for (int i = 0; i < size; i++)
    {
        if (arr[i] != 'a' && arr[i] != 'e' && arr[i] != 'i' && arr[i] != 'o' && arr[i] != 'u' &&
            arr[i] != 'A' && arr[i] != 'E' && arr[i] != 'I' && arr[i] != 'O' && arr[i] != 'U')
        {
            arr[j] = arr[i];
            j++;
        }
    }
    arr[j] = '\0';
    cout << "String after deleting vowels: " << arr << endl;
}

int main()
{

    char s1[100];

    cout << "Enter the string: ";
    cin.getline(s1, 100);

    int size = 0;
    while (s1[size] != '\0')
    {
        size++;
    }

    deleteVowels(s1, size);
    
    return 0;
}