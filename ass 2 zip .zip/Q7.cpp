/*Let A[1 …. n] be an array of n real numbers. A pair (A[i], A[j ]) is said to be an
inversion if these numbers are out of order, i.e., i < j but A[i]>A[j ]. Write a program to
count the number of inversions in an array.*/


#include <iostream>
using namespace std;

// Function to merge two halves of the array and count inversions
int mergeAndCount(int arr[], int temp[], int left, int mid, int right) {
    int i = left;    // Starting index for left subarray
    int j = mid + 1; // Starting index for right subarray
    int k = left;    // Starting index to store merged elements
    int invCount = 0;

    // Merge the two subarrays
    while (i <= mid && j <= right) {
        if (arr[i] <= arr[j]) {
            temp[k++] = arr[i++];
        } else {
            temp[k++] = arr[j++];
            invCount += (mid - i + 1); // Count inversions
        }
    }

    // Copy remaining elements of left subarray
    while (i <= mid) {
        temp[k++] = arr[i++];
    }

    // Copy remaining elements of right subarray
    while (j <= right) {
        temp[k++] = arr[j++];
    }

    // Copy the sorted subarray back to the original array
    for (i = left; i <= right; i++) {
        arr[i] = temp[i];
    }

    return invCount;
}

// Function to use merge sort and count inversions
int mergeSortAndCount(int arr[], int temp[], int left, int right) {
    int invCount = 0;
    if (left < right) {
        int mid = (left + right) / 2;

        // Count inversions in the left subarray
        invCount += mergeSortAndCount(arr, temp, left, mid);

        // Count inversions in the right subarray
        invCount += mergeSortAndCount(arr, temp, mid + 1, right);

        // Count inversions during the merge step
        invCount += mergeAndCount(arr, temp, left, mid, right);
    }
    return invCount;
}

int main() {
    int arr[] = {8, 4, 2, 1};
    int n = sizeof(arr) / sizeof(arr[0]);
    int temp[n];

    int inversionCount = mergeSortAndCount(arr, temp, 0, n - 1);

    cout << "Number of inversions: " << inversionCount << endl;

    return 0;
}