//efficient way to store upper triangular matrix in 1d array

#include <iostream>
using namespace std;

// Function to map 2D indices to 1D index for upper triangular matrix
int mapIndex(int i, int j, int n) {
    return (i * n - (i * (i + 1)) / 2 + j - i);
}

// Function to store upper triangular matrix in a 1D array
void storeUpperTriangular(int n, int matrix[][100], int upperArray[]) {
    int index = 0;

    for (int i = 0; i < n; i++) {
        for (int j = i; j < n; j++) {
            upperArray[index++] = matrix[i][j];
        }
    }
}

// Function to print the 1D array
void printUpperTriangular(int upperArray[], int size) {
    for (int i = 0; i < size; i++) {
        cout << upperArray[i] << " ";
    }
    cout << endl;
}

int main() {
    int n = 4; // Size of the matrix
    int matrix[100][100] = {
        {1, 2, 3, 4},
        {0, 5, 6, 7},
        {0, 0, 8, 9},
        {0, 0, 0, 10}
    };

    int upperArray[n * (n + 1) / 2]; // 1D array to store the upper triangular elements

    storeUpperTriangular(n, matrix, upperArray);

    cout << "Upper triangular matrix stored in 1D array: ";
    printUpperTriangular(upperArray, n * (n + 1) / 2);

    return 0;
}