//transpose of a mattrix in sparse matrix

#include <iostream>
using namespace std;

// Function to display the sparse matrix in triplet form
void displaySparseMatrix(int sparse[][3], int size) {
    cout << "Row\tCol\tValue" << endl;
    for (int i = 0; i < size; i++) {
        cout << sparse[i][0] << "\t" << sparse[i][1] << "\t" << sparse[i][2] << endl;
    }
}

// Function to compute the transpose of a sparse matrix
void transposeSparseMatrix(int sparse[][3], int size, int transposed[][3]) {
    // Copy the number of rows, columns, and non-zero elements
    transposed[0][0] = sparse[0][1]; // New row count = old column count
    transposed[0][1] = sparse[0][0]; // New column count = old row count
    transposed[0][2] = sparse[0][2]; // Number of non-zero elements remains the same

    // Transpose the elements (swap row and column indices)
    int k = 1;
    for (int i = 1; i <= sparse[0][2]; i++) {
        transposed[k][0] = sparse[i][1]; // New row = old column
        transposed[k][1] = sparse[i][0]; // New column = old row
        transposed[k][2] = sparse[i][2]; // Value remains the same
        k++;
    }

    // Optional: Sort the transposed matrix by row and column indices
    for (int i = 1; i < transposed[0][2]; i++) {
        for (int j = i + 1; j <= transposed[0][2]; j++) {
            if (transposed[i][0] > transposed[j][0] || 
               (transposed[i][0] == transposed[j][0] && transposed[i][1] > transposed[j][1])) {
                swap(transposed[i], transposed[j]);
            }
        }
    }
}

int main() {
    // Sparse matrix in triplet form: [row, col, value]
    int sparse[5][3] = {
        {4, 4, 4}, // 4x4 matrix with 4 non-zero elements
        {0, 1, 5},
        {1, 2, 8},
        {2, 0, 3},
        {3, 3, 6}
    };

    // Transposed sparse matrix
    int transposed[5][3];

    // Compute the transpose
    transposeSparseMatrix(sparse, 5, transposed);

    // Display the original sparse matrix
    cout << "Original Sparse Matrix:" << endl;
    displaySparseMatrix(sparse, 5);

    // Display the transposed sparse matrix
    cout << "\nTransposed Sparse Matrix:" << endl;
    displaySparseMatrix(transposed, 5);

    return 0;
}