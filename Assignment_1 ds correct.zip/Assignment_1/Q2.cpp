/*Design the logic to remove the duplicate elements from an Array and after the
deletion the array should contain the unique elements.*/

#include <iostream>
using namespace std;

void removeDuplicates(int arr[], int &size)
{
    if (size == 0 || size == 1) {
        return; // No duplicates in empty or single element array
    }

    int newSize = 0; // New size of the array after removing duplicates
    for (int i = 0; i < size; i++) {
        bool isDuplicate = false;
        for (int j = 0; j < newSize; j++) {
            if (arr[i] == arr[j]) {
                isDuplicate = true;
                break;
            }
        }
        if (!isDuplicate) {
            arr[newSize++] = arr[i]; // Add unique element to the new position
        }
    }
    size = newSize; // Update the size of the array
}

int main() {
    int arr[100], size = 0;

    cout << "Enter the number of elements in the array: ";
    cin >> size;
    cout << "Enter the elements of the array:\n";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    removeDuplicates(arr, size);

    cout << "Array after removing duplicates:\n";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}