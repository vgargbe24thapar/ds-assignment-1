//program to find sum of every row and column in a matrix
#include <iostream>
using namespace std;

void sumOfRowsAndColumns(int matrix[10][10], int rows, int cols) {
    int rowSum[10] = {0};
    int colSum[10] = {0};

    // Calculate sum of each row and column
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            rowSum[i] += matrix[i][j];
            colSum[j] += matrix[i][j];
        }
    }

    // Print row sums
    cout << "Sum of each row:\n";
    for (int i = 0; i < rows; i++) {
        cout << "Row " << i + 1 << ": " << rowSum[i] << endl;
    }

    // Print column sums
    cout << "Sum of each column:\n";
    for (int j = 0; j < cols; j++) {
        cout << "Column " << j + 1 << ": " << colSum[j] << endl;
    }
}

int main() {
    int matrix[10][10];
    int rows, cols;

    cout << "Enter number of rows and columns: ";
    cin >> rows >> cols;

    cout << "Enter elements of the matrix:\n";
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cin >> matrix[i][j];
        }
    }

    sumOfRowsAndColumns(matrix, rows, cols);

    return 0;
}