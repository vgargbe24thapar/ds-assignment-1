#include <iostream>
using namespace std;

/*Develop a Menu driven program to demonstrate the following operations of Arrays
——MENU——-
1.CREATE
2. DISPLAY
3. INSERT
4. DELETE
5. LINEAR SEARCH
6. EXIT
*/

void createArray(int arr[], int &size) {
    cout << "Enter the number of elements: ";
    cin >> size;
    cout << "Enter the elements: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }
}

void chooseOption(int arr[], int &size) {
    int option;
    do {
        cout << "\n--- MENU ---\n";
        cout << "1. CREATE\n";
        cout << "2. DISPLAY\n";
        cout << "3. INSERT\n";
        cout << "4. DELETE\n";
        cout << "5. LINEAR SEARCH\n";
        cout << "6. EXIT\n";
        cout << "Choose an option: ";
        cin >> option;

        switch (option) {
            case 1:
                createArray(arr, size);
                break;
            case 2:
                if (size == 0) {
                    cout << "Array is empty.\n";
                } else {
                    cout << "Array elements: ";
                    for (int i = 0; i < size; i++) {
                        cout << arr[i] << " ";
                    }
                    cout << endl;
                }
                break;
            case 3:
                // Insert operation can be implemented here
                insertArray(arr, size);
                break;
            case 4:
                // Delete operation can be implemented here
                deleteArray(arr, size);
                break;
            case 5:
                // Linear search operation can be implemented here
                searchArray(arr, size);
                break;
            case 6:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid option! Please try again.\n";
        }
    } while (option != 6);
}

void insertArray(int arr[], int &size) {
    if (size >= 100) {
        cout << "Array is full. Cannot insert more elements.\n";
        return;
    }
    int element;
    cout << "Enter the element to insert: ";
    cin >> element;
    arr[size++] = element; // Add the new element and increase size
    cout << "Element inserted successfully.\n";
}

void deleteArray(int arr[], int &size) {
    if (size == 0) {
        cout << "Array is empty. Cannot delete elements.\n";
        return;
    }
    int index;
    cout << "Enter the index of the element to delete (0 to " << size - 1 << "): ";
    cin >> index;
    if (index < 0 || index >= size) {
        cout << "Invalid index! No element deleted.\n";
        return;
    }
    for (int i = index; i < size - 1; i++) {
        arr[i] = arr[i + 1]; // Shift elements to the left
    }
    size--; // Decrease the size of the array
    cout << "Element deleted successfully.\n";
}

void searchArray(int arr[], int size) {
    if (size == 0) {
        cout << "Array is empty. Cannot perform search.\n";
        return;
    }
    int element;
    cout << "Enter the element to search: ";
    cin >> element;
    for (int i = 0; i < size; i++) {
        if (arr[i] == element) {
            cout << "Element found at index: " << i << endl;
            return;
        }
    }
    cout << "Element not found in the array.\n";
}


int main() {
    int arr[100]; // Array to hold elements
    int size = 0; // Current size of the array

    chooseOption(arr, size);

    return 0;
}